Alter table demodb.tblnhanvien add fulltext (ten);
show index from  demodb.tblnhanvien;